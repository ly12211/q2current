'''
Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
Date: 2024-03-19 14:20:50
LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
LastEditTime: 2024-03-21 16:39:32
FilePath: /ly/singlelevellindms.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
from openlind import *
from classgate import *
from numpy import trace,sum
# totq,ltlt=singlelevlindmaster(1,0)
# ltlt=isingmd(0,2).liolio
# ltlt=qubit_operator_sparse(ltlt)
# print (ltlt.todense())

def dhea(x,d1,d2,totq):
    workq=int(totq/2)
    k=0
    fa0=1j*zeros((2**workq,1))
    fa0[0]=1.0+0j
    circ=fa0
    qgt=[]
    dqgt=[]
    uwork=eye(2**workq)
    for i in range(d1):
        for nq in range(workq):
            qc=U3(x[k],x[k+1],x[k+2],nq,workq)
            qgt.append(qc.x1)
            qgt.append(qc.x2)
            qgt.append(qc.x3)
            dqgt.append(qc.grad1)
            dqgt.append(qc.grad2)
            dqgt.append(qc.grad3)
            circ=qc.x@circ
            k=k+3
            del qc
        for nq in range(workq-1):
            qc=RXX(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RYY(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RZZ(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
    circa=circ
    circb=fa0
    cica=[circ for x in range(2**workq)]
    cicb=[fa0 for x in range(2**workq)]
    tp_left=[k00,k11]
    tp_right=[eye(2),sigma_x]
    for i in range(2**workq):
        bin2=to_bin(i,workq)
        for j in range(workq):
            singlegatel=tp_left[int(bin2[j])]
            singlegater=tp_right[int(bin2[j])]
            cica[i]=Circ_Singlegate(singlegatel,j,workq)@cica[i]
            cicb[i]=Circ_Singlegate(singlegater,j,workq)@cicb[i]

    for nq in range(workq):
        qc=CX(nq,nq+workq,totq)
        qgt.append(qc.x)
        dqgt.append(qc.grad)
        k=k+1
        del qc
    for i in range(d2):
        for nq in range(workq):
            qc=U3(x[k],x[k+1],x[k+2],nq,workq)
            qgt.append(qc.x1)
            qgt.append(qc.x2)
            qgt.append(qc.x3)
            dqgt.append(qc.grad1)
            dqgt.append(qc.grad2)
            dqgt.append(qc.grad3)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+3
            del qc
        for nq in range(workq-1):
            qc=RXX(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RYY(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RZZ(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
    circ=0
    for i in range(2**workq):
        circ+=kron(cica[i],cicb[i])

    return circ,qgt,dqgt

def np_dhea(d1,d2,totq):
    workq=int(totq/2)
    k=0
    for i in range(d1):
        for nq in range(workq):
            k=k+3
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
    for nq in range(workq):
            k=k+1
    n2=k
    for i in range(d2):
        for nq in range(workq):
            k=k+3
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
    return k,n2


Nfeval = 1


def ising_solver(size,d1,d2):
    xba=[]
    yba=[]
    zba=[]
    Xba=[]
    Yba=[]
    Zba=[]
    idx=[]
    method='BFGS'
    nprm,n2=np_dhea(d1,d2,size*2)
    pram=zeros(nprm)
    
    xb=UX(0,size).x
    yb=UY(0,size).x
    zb=UZ(0,size).x
    sz=2**size
    iwork=eye(2**size)
    for i in range(15):
        print('ite:',i)
        g_pra=i*0.2
        ltlt=isingmd(g_pra,size).liolio
        ltlt=qubit_operator_sparse(ltlt)
        
        def ell(x):
            fx,qg,dqg=dhea(x,d1,d2,size*2)
            fai=fx
            fx=ltlt@fx
            inner=trace(fai.conj().T@fx)
            lamb=fx
            jac=zeros(nprm)
            for i in range(nprm-1,-1,-1):
                if i>=n2:
                    qg0=kron(qg[i].conj().T,qg[i].transpose())
                    fai=qg0@fai
                    uv=fai
                    uv=(kron(dqg[i],(qg[i]).conj())+kron(qg[i],(dqg[i]).conj()))@uv
                    jac[i]=2*(trace(lamb.conj().T@uv)).real
                else:
                    if i>=n2-size:
                        fai=qg[i].conj().T@fai
                        jac[i]=0
                    else:
                        qg0=kron(qg[i].conj().T,iwork)
                        fai=qg0@fai
                        uv=fai
                        uv=kron(dqg[i],iwork)@uv
                        jac[i]=2*(trace(lamb.conj().T@uv)).real

                if i>=n2 or i<n2-size:
                    lamb=qg0@lamb
                else:
                    lamb=qg[i].conj().T@lamb
            return inner ,jac
        def callbackF(Xi):
            global Nfeval
            rs,rg=ell(Xi)
            print (Nfeval, rs)
            with open("optdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(Xi))
                f.close()
            with open("gradparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(rg))
                f.close()
            with open("opt%s%s.txt"%(d1,d2),"a") as f2:
                f2.write(str(rs))
                f2.write("\n")
                f2.close()
            Nfeval += 1
        opt=optz.minimize(ell, x0=pram,method=method,jac=True,callback=callbackF)
        with open("dvqeparameters%s%s.txt"%(d1,d2),"a") as fp:
            fp.write(str(opt.x))
            fp.write("\n")
            fp.close()
        ev,qg,dqg=dhea(opt.x,d1,d2,size*2)
        # ev=ev.reshape(size(ev))
        rou=ev.reshape(sz,sz)
        rou=rou/trace(rou)
        ed,vd=scipy.sparse.linalg.eigsh(ltlt,k=1,which='SA')
        roud=vd.reshape(sz,sz)
        roud=roud/trace(roud)
        xba.append((rou@xb).trace())
        yba.append((rou@yb).trace())
        zba.append((rou@zb).trace())
        Xba.append((roud@xb).trace())
        Yba.append((roud@yb).trace())
        Zba.append((roud@zb).trace())
        idx.append(g_pra)
        pram=opt.x
    mpl.plot(idx,xba,'ro')
    mpl.plot(idx,yba,'bo')
    mpl.plot(idx,zba,'co')
    mpl.plot(idx,Xba,'r-')
    mpl.plot(idx,Yba,'b-')
    mpl.plot(idx,Zba,'c-')
    mpl.savefig("ising%s%s.png"%(d1,d2))

def junction(nlead):
    fo=0
    for i in range(1,nlead+1):
        fo=fo-1j*(FermionOperator((i,1))*FermionOperator((0,0))-FermionOperator((0,1))*FermionOperator((i,0))-(FermionOperator((i+nlead,1))*FermionOperator((0,0))-FermionOperator((0,1))*FermionOperator((i+nlead,0))))
    qo=jordan_wigner(fo)
    return(qubit_operator_sparse(qo))


def singlelevelmod_solver(nleadlvs,d1,d2):
    occ=[]
    occ_d=[]
    idx=[]
    jc=[]
    jc_d=[]
    method='BFGS'
    size=(nleadlvs+1)*2+1
    sz=2**size
    nprm,n2=np_dhea(d1,d2,size*2)
    pram=zeros(nprm)
    pram=[ 
  1.48530269e-06, -5.95812650e+00,  3.14159194e+00,  1.48519039e-06,
  2.59446465e+00,  1.57080500e+00,  1.48495000e-06,  2.49718600e+00,
 -1.52989296e+00,  1.48527796e-06,  4.67841444e+00,  1.87045757e+00,
  1.48501399e-06,  1.72105099e-06, -1.60834537e+00, -2.05367079e+00,
 -4.42886032e-07, -1.20540863e+00,  1.02732216e-06, -4.13755651e+00,
 -2.62659121e-06,  1.51677504e+00, -6.39187661e-09, -6.87234742e-06,
  4.92269622e+00, -7.22932905e+00,  1.51158444e+00,  0.00000000e+00,
  0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
  3.33401339e-04, -2.34751314e-11, -1.44660915e+01,  8.23896575e-04,
 -3.18839623e-11,  4.08753928e+00,  3.63184814e-04, -1.57393571e-09,
 -6.52529370e+00,  9.72634692e-04,  2.33605580e-10,  2.41605935e-01,
  3.28497870e-04,  4.22485006e-10, -1.43385905e+00,  2.16786247e+00,
  2.28896943e-02,  1.05754610e-02, -9.91623124e-01,  1.10968490e+00,
  3.45728352e-02,  9.04728567e-02,  6.25027120e-01, -7.50577299e-04,
 -6.28320301e+00, -8.82494268e-08,  3.56542947e-05, -4.66070509e+00,
 -1.24232072e-10,  5.77791201e+00, -2.58206453e+00, -7.06587511e-11,
  1.60057087e+00,  8.81888210e-01, -7.64980981e-11, -6.80644694e-01,
 -2.65614376e+00, -3.34019983e-11,  2.66538205e+00,  4.96068186e+00,
  5.37086500e-10, -7.78806637e+00,  2.70953392e+00, -3.13318432e+00,
 -6.60953057e-02,  5.55620926e-01, -5.61808388e-01,  1.56654086e+00,
  1.14482141e-01, -9.24631946e-01, -7.62688831e-05, -2.51544436e-05,
 -7.73302320e-06,  1.38263275e-01, -3.82683416e+00,  1.28377946e-10,
  1.78226284e+00, -1.34990178e-01,  4.23539884e-11,  6.43268076e+00,
 -5.72807998e+00,  5.19262319e-12,  5.76310316e+00,  4.97271447e+00,
  6.71181396e-11, -3.24288418e+00, -1.32142196e-01,  9.89736713e-11,
  1.06522477e-01, -1.59543854e+00,  1.58423013e+00, -3.71132816e-04,
 -1.78904584e+00, -1.55123151e+00, -3.27412568e+00, -3.69161548e-04,
  1.67932845e+00, -3.13217721e+00, -3.14204906e+00,  3.14165620e+00,
 -1.38254914e-01]
    iwork=eye(2**size)
    n_s=jordan_wigner(FermionOperator("0^ 0"))
    n_s=qubit_operator_sparse(n_s)
    uw=eye(2**(size-1))
    n_s=kron(n_s.todense(),uw)
    jcop=junction(nleadlvs+1)
    # n_s=kron(n_s,pwkron(id2,size-1))
    # n_1=jordan_wigner(FermionOperator("1^ 0",1j)-FermionOperator("0^ 1",1j))
    # n_s=openfermion2qiskit_qubitlist(n_s,size)
    # n_1=openfermion2qiskit_qubitlist(n_1,size)
    # n_s=PauliSumOp.from_list(n_s).to_matrix()
    # n_1=PauliSumOp.from_list(n_1).to_matrix()
    with open("data%s%s.txt"%(d1,d2),"a") as f2:
        f2.write('idx      occ     occ_d      jc      jc_d')
        f2.write("\n")
        f2.close()
    for i in range(12,21):
        print('ite:',i)
        # g_pra=-3+i*0.5
        g_pra=1.0+i
    
        tq,ltlt,t_cp=singlelevlindmaster(nleadlvs,-3,g_pra)
        ltlt=qubit_operator_sparse(ltlt)
        ed,vd=scipy.sparse.linalg.eigsh(ltlt,k=1,which='SA')
        roud=vd.reshape(sz,sz)
        roud=roud/trace(roud)
        def ell(x):
            fx,qg,dqg=dhea(x,d1,d2,size*2)
            fai=fx
            fx=ltlt@fx
            inner=(fai.conj().T@fx).sum()
            lamb=fx
            jac=zeros(nprm)
            for i in range(nprm-1,-1,-1):
                if i>=n2:
                    qg0=kron(qg[i].conj().T,qg[i].transpose())
                    fai=qg0@fai
                    uv=fai
                    uv=(kron(dqg[i],(qg[i]).conj())+kron(qg[i],(dqg[i]).conj()))@uv
                    jac[i]=2*((lamb.conj().T@uv).trace()).real
                else:
                    if i>=n2-size:
                        fai=qg[i].conj().T@fai
                        jac[i]=0
                    else:
                        qg0=kron(qg[i].conj().T,iwork)
                        fai=qg0@fai
                        uv=fai
                        uv=kron(dqg[i],iwork)@uv
                        jac[i]=2*((lamb.conj().T@uv).trace()).real
                if i>=n2 or i<n2-size:
                    lamb=qg0@lamb
                else:
                    lamb=qg[i].conj().T@lamb
            return inner ,jac
        def callbackF(Xi):
            global Nfeval
            rs,rg=ell(Xi)
            print (Nfeval, rs)
            with open("optdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(Xi))
                f.close()
            with open("gradparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(rg))
                f.close()
            def print_gate_np_dhea(totq,x):
                with open("gateoptdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                    workq=int(totq/2)
                    k=0
                    f.write('Parameters in D\n')
                    for i in range(d1):
                        for nq in range(workq):
                            f.write(('qubit:%s  Gate:U3 Pm%s %s %s\n'%(nq,x[k],x[k+1],x[k+2])))
                            k=k+3
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RXX Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RYY Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RZZ Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                    for nq in range(workq):
                            f.write('qubit:%s qubit:%s  Gate:CX Pm%s\n'%(nq,nq+workq,x[k]))
                            k=k+1
                    f.write('Parameters in V\n')
                    for i in range(d2):
                        for nq in range(workq):
                            f.write('qubit:%s  Gate:U3 Pm%s %s %s\n'%(nq,x[k],x[k+1],x[k+2]))
                            k=k+3
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RXX Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RYY Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RZZ Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1 
                    f.close()
            print_gate_np_dhea(size*2,Xi)
            with open("opt%s%s.txt"%(d1,d2),"a") as f2:
                f2.write(str(rs))
                f2.write("\n")
                f2.close()
            Nfeval += 1
        opt=optz.minimize(ell, x0=pram,method=method,jac=True,callback=callbackF)
        with open("dvqeparameters%s%s.txt"%(d1,d2),"a") as fp:
            fp.write(str(opt.x))
            fp.write("\n")
            fp.close()
        ev,qg,dqg=dhea(opt.x,d1,d2,size*2)
        # ev=ev.reshape(size(ev))
        rou=ev.reshape(sz,sz)
        rou=rou/rou.trace()
        idx.append(g_pra)
        tocc=np.sum((rou@n_s).trace())
        tocc_d=np.sum((roud@n_s).trace())
        occ.append(tocc)
        occ_d.append(tocc_d)
        tjc=t_cp*(rou@jcop).trace()
        jc.append(tjc)
        tjc_d=t_cp*(rou@jcop).trace()
        jc_d.append(tjc_d)
        with open("data%s%s.txt"%(d1,d2),"a") as f2:
            f2.write(str(g_pra))
            f2.write("   ")
            f2.write(str(tocc))
            f2.write("   ")
            f2.write(str(tocc_d))
            f2.write("   ")
            f2.write(str(tjc))
            f2.write("   ")
            f2.write(str(tjc_d))
            f2.write("\n")
            f2.close()
        pram=opt.x

    fig1=mpl.figure(num=1)
    mpl.plot(idx,occ,'ro')
    mpl.plot(idx,occ_d,'r-')
    mpl.xlabel('V')
    mpl.ylabel('Occ Num',rotation=0)
    mpl.legend(['vqe','direct_diagnoalization'])
    mpl.savefig("occdg%s%s.png"%(d1,d2))

    fig1=mpl.figure(num=2)
    mpl.plot(idx,jc,'ro')
    mpl.plot(idx,jc_d,'r-')
    mpl.xlabel('V')
    mpl.ylabel('I',rotation=0)
    mpl.legend(['vqe','direct_diagnoalization'])
    mpl.savefig("jcdg%s%s.png"%(d1,d2))


# ising_solver(3,1,2)
singlelevelmod_solver(1,1,3)

