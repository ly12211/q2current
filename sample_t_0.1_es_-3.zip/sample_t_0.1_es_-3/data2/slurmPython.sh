#!/bin/bash
#SBATCH --job-name=T_ly_uv
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --output=%j.log
#SBATCH --partition=normal

#load the environment
module use /public/software/modulefiles/
module load python

stdbuf -o0 -e0 python singlelevellindms.py >run.log

# Output file is ...:         PythonTest.log

