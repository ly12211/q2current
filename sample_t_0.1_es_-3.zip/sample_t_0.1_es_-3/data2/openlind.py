'''
Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
Date: 2023-12-10 17:07:06
LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
LastEditTime: 2024-03-19 14:32:40
FilePath: /ly/openlind.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import openfermion
from openfermion import *
import numpy as np
from math import *
from classgate import *
import math





def trans_FermionOperator(fermionop,nacc):
    newkey={}
    fo=FermionOperator()
    for terms in fermionop.terms.keys():
        new_list=[]
        for tp in list(terms):
            new_list.append((list(tp)[0]+nacc,list(tp)[1]))
        new_terms=tuple(new_list)
        newkey[new_terms]=fermionop.terms[terms]
    fo.terms=newkey
    return fo

def kr_jordanwigner(fermionop,nacc):
    fermionop_trans=trans_FermionOperator(fermionop,nacc)
    kr_jw_qbitop=QubitOperator()
    zstring=[]
    for i in range(nacc):
        zstring.append((i,'Z'))
    for terms in fermionop_trans.terms.keys():
        sz=len(list(terms))
        zs=QubitOperator(tuple(zstring))
        fo=FermionOperator(tuple(terms),fermionop_trans.terms[terms])
        kr_jw_qbitop=kr_jw_qbitop+zs**(sz%2)*jordan_wigner(fo)
    return kr_jw_qbitop
    
def trans_QubitOperator(qubitop,nacc):
    newkey={}
    qo=QubitOperator()
    for terms in qubitop.terms.keys():
        new_list=[]
        for tp in list(terms):
            new_list.append((list(tp)[0]+nacc,list(tp)[1]))
        new_terms=tuple(new_list)
        newkey[new_terms]=qubitop.terms[terms]
    qo.terms=newkey
    return qo    


def singlelevel_ham_fermionop(efmion,tcp):
    nspace=len(efmion)
    singlelevel_ham=FermionOperator()
    for i in range(nspace):
        singlelevel_ham+=FermionOperator(((i,1),(i,0)),efmion[i])
    for i in range(1,nspace):
        singlelevel_ham+=-FermionOperator(((i,1),(0,0)),tcp)-FermionOperator(((0,1),(i,0)),tcp)
    return singlelevel_ham

def construct_choi_fermion2qubit_dissipator(efmion_list,nspace):
    lindop=QubitOperator()
    for efermion in efmion_list:
        jw_ck1=jordan_wigner(efermion)
        jw_ck1_trans=kr_jordanwigner(efermion,nspace)
        lindop+=jw_ck1*jw_ck1_trans-0.5*hermitian_conjugated(jw_ck1)*jw_ck1-0.5*hermitian_conjugated(jw_ck1_trans)*jw_ck1_trans
    return lindop

def construct_choi_qubit2qubit_dissipator(qubitop_list,nspace):
    lindop=QubitOperator()
    for qubitop in qubitop_list:
        jw_ck1=qubitop
        jw_ck1_trans=trans_QubitOperator(qubitop,nspace)
        lindop+=jw_ck1*jw_ck1_trans-0.5*hermitian_conjugated(jw_ck1)*jw_ck1-0.5*hermitian_conjugated(jw_ck1_trans)*jw_ck1_trans
    return lindop

def elephon(n_leads_level,es,chem_u,w0,kwa):
    qubit_tot=2*(n_leads_level+1)+2
    N=n_leads_level
    T=0.1
    TL=T
    TR=T
    de=10/N
    yita=(N+1)/10
    gama=2*de
    chem_u=chem_u
    UL=chem_u/2.0
    UR=-chem_u/2.0
    t_cp=sqrt(1/(2*pi*yita))
    ek=[es,-5,5,-5,5]
    fd=lambda x,u,T:1.0/(1+math.exp((x-u)/T))
    def diag_lind(t):
        sigma_x=array([[0.,1],[1.,0]])
        sigma_y=array([[0.,-1.j],[1.j,0]])
        sigma_z=array([[1,0],[0,-1]])
        sigma_p=(sigma_x+1.j*sigma_y)/2
        I2=(eye(2))
        I4=(eye(4))
        I8=(eye(8))
        I32=(eye(32))

        Z4=kron(sigma_z,sigma_z)
        Z8=kron(Z4,sigma_z)
        ak=[]
        dk=[]
        ak.append((kron(sigma_p,I32)))
        ak.append((kron(sigma_z,kron(kron(sigma_p,I2),I8))))
        ak.append((kron(sigma_z,kron(kron(sigma_z,sigma_p),I8))))
        ak.append((kron(Z8,(kron(sigma_p,I4)))))
        ak.append(kron(kron(Z8,kron(sigma_z,sigma_p)),I2))
        dk.append((kron(I32,sigma_p)))
        
        ham=lambda es,ek:es*ak[0].conj().T@ak[0]+w0*dk[0].conj().T@dk[0]+kwa*ak[0].conj().T@ak[0]@(dk[0].conj().T+dk[0])\
            +ek[1]*ak[1].conj().T@ak[1]\
            +ek[2]*ak[2].conj().T@ak[2]\
            +ek[3]*ak[3].conj().T@ak[3]\
            +ek[4]*ak[4].conj().T@ak[4]\
            -t*(ak[1].conj().T+ak[2].conj().T+ak[3].conj().T+ak[4].conj().T)@ak[0]\
            -t*(ak[0].conj().T@(ak[1]+ak[2]+ak[3]+ak[4]))
        DLind=lambda ck:(kron(ck,ck.conj())-kron(0.5*ck.conj().T@ck,eye(ck.shape[0]))-kron(eye(ck.shape[0]),0.5*ck.T@ck.conj()))
        l1=[0 for x in range(5)]
        l2=[0 for x in range(5)]
        l1[1]=sqrt(gama*(1-fd(ek[1],UL,TL)))*ak[1]
        l1[2]=sqrt(gama*(1-fd(ek[2],UL,TL)))*ak[2]
        l1[3]=sqrt(gama*(1-fd(ek[3],UR,TR)))*ak[3]
        l1[4]=sqrt(gama*(1-fd(ek[4],UR,TR)))*ak[4]
        l2[1]=sqrt(gama*(fd(ek[1],UL,TL)))*ak[1].conj().T
        l2[2]=sqrt(gama*(fd(ek[2],UL,TL)))*ak[2].conj().T
        l2[3]=sqrt(gama*(fd(ek[3],UR,TR)))*ak[3].conj().T
        l2[4]=sqrt(gama*(fd(ek[4],UR,TR)))*ak[4].conj().T

        lind=lambda es,ek:-1.j*(kron((ham(es,ek)),eye(ham(es,ek).shape[0]))-kron(eye(ham(es,ek).shape[0]),ham(es,ek).T))\
            +2*(DLind(l1[1])+DLind(l1[2])+DLind(l1[3])+DLind(l1[4])+DLind(l2[1])+DLind(l2[2])+DLind(l2[3])+DLind(l2[4]))
        ll=lambda es,ek:lind(es,ek).conj().T@lind(es,ek)    
        return ll(es,ek)

    liolio=diag_lind(t_cp)
    return qubit_tot ,liolio,t_cp

def junction(t,ak,rou):
    sja=0
    sjb=0
    nlead=(len(ak)-1)/2
    a0=ak[0]
    for k in range(1,3):
        sja=sja-(trace(1j*(rou@(ak[k].conj().T@a0-a0.conj().T@ak[k]))))
        sjb=sjb-(trace(1j*(rou@(ak[k+nlead].conj().T@a0-a0.conj().T@ak[k+nlead]))))
    y=t*(sja-sjb)/2
    return y

def singlelevlindmaster(n_leads_level,es,chem_u):
    N=n_leads_level
    T=0.1
    TL=T
    TR=T
    de=10/N
    yita=(N+1)/10
    gama=2*de
    chem_u=chem_u
    t_cp=sqrt(1/(2*pi*yita))

    fd=lambda x,u,T:1.0/(1+exp((x-u)/T))

    def kjw_lindbladop(efmion):
        nspace=len(efmion)
        nlead=(nspace-1)/2
        lindop=QubitOperator()
        for i in range(1,nspace):
            if i<(nlead+1):
                uu=chem_u/2.0
                tep=TL
            else:
                uu=-chem_u/2.0
                tep=TR
            ck1=FermionOperator((i,0),sqrt(gama*(1-fd(ek[i],uu,tep))))
            ck2=FermionOperator((i,1),sqrt(gama*(fd(ek[i],uu,tep))))
            jw_ck1=jordan_wigner(ck1)
            jw_ck1_trans=kr_jordanwigner(ck1,nspace)
            jw_ck2=jordan_wigner(ck2)
            jw_ck2_trans=kr_jordanwigner(ck2,nspace)
            lindop+=jw_ck1*jw_ck1_trans-0.5*hermitian_conjugated(jw_ck1)*jw_ck1-0.5*hermitian_conjugated(jw_ck1_trans)*jw_ck1_trans
            lindop+=jw_ck2*jw_ck2_trans-0.5*hermitian_conjugated(jw_ck2)*jw_ck2-0.5*hermitian_conjugated(jw_ck2_trans)*jw_ck2_trans
        return lindop

    def single_lev_lind_fermion_op(efmion):
        nspace=len(efmion)
        nlead=(nspace-1)/2
        l1=[]
        l2=[]
        for i in range(1,nspace):
            if i<(nlead+1):
                uu=chem_u/2.0
                tep=TL
            else:
                uu=-chem_u/2.0
                tep=TR
            l1.append(FermionOperator((i,0),sqrt(gama*(1-fd(ek[i],uu,tep)))))
            l2.append(FermionOperator((i,1),sqrt(gama*(fd(ek[i],uu,tep)))))
        return l1,l2

    def single_lev_lind_qubit_op(efmion):
        nspace=len(efmion)
        nlead=(nspace-1)/2
        l1,l2=single_lev_lind_fermion_op(efmion)
        q1=[]
        q2=[]
        for i in range(len(l1)):
            q1.append(jordan_wigner(l1[i]))
            q2.append(jordan_wigner(l2[i]))

        return q1,q2

    def liouville_qubit_superop(hamiltonian,efmion):
        nspace=len(efmion)
        jw_ham=jordan_wigner(hamiltonian)
        jw_ham_trans=kr_jordanwigner(hamiltonian,nspace)
        # return -1.j*(jw_ham-jw_ham_trans)+2*kjw_lindbladop(efmion)
        # l1,l2=single_lev_lind_fermion_op(efmion)
        # jl1=construct_choi_fermion2qubit_dissipator(l1,nspace)
        # jl2=construct_choi_fermion2qubit_dissipator(l2,nspace)
        # return -1.j*(jw_ham-jw_ham_trans)+2*(jl1+jl2)
        l1,l2=single_lev_lind_qubit_op(efmion)
        jl1=construct_choi_qubit2qubit_dissipator(l1,nspace)
        jl2=construct_choi_qubit2qubit_dissipator(l2,nspace)
        return -1.j*(jw_ham-jw_ham_trans)+2*(jl1+jl2)


    def diag_lind(t):
        sigma_x=csc_matrix(np.array([[0.,1],[1.,0]]))
        sigma_y=csc_matrix(np.array([[0.,-1.j],[1.j,0]]))
        sigma_z=csc_matrix(np.array([[1,0],[0,-1]]))
        sigma_p=(sigma_x+1.j*sigma_y)/2
        I2=(eye(2))
        I4=(eye(4))
        I16=(eye(16))
        Z4=kron(sigma_z,sigma_z)
        Z8=kron(Z4,sigma_z)
        ak=[]
        ak.append((kron(sigma_p,I16)))
        ak.append((kron(sigma_z,kron(kron(sigma_p,I2),I4))))
        ak.append((kron(sigma_z,kron(kron(sigma_z,sigma_p),I4))))
        ak.append((kron(Z8,(kron(sigma_p,I2)))))
        ak.append((kron(Z8,kron(sigma_z,sigma_p))))
        fd=lambda x,u,T:1.0/(1+math.exp((x-u)/T))
        ek=[es,-5,5,-5,5]
        ham=lambda es,ek:es*ak[0].conj().T@ak[0]\
            +ek[1]*ak[1].conj().T@ak[1]\
            +ek[2]*ak[2].conj().T@ak[2]\
            +ek[3]*ak[3].conj().T@ak[3]\
            +ek[4]*ak[4].conj().T@ak[4]\
            -t*(ak[1].conj().T+ak[2].conj().T+ak[3].conj().T+ak[4].conj().T)@ak[0]\
            -t*(ak[0].conj().T@(ak[1]+ak[2]+ak[3]+ak[4]))
        DLind=lambda ck:(kron(ck,np.conj(ck))-kron(0.5*ck.conj().T@ck,eye(ck.shape[0]))-kron(eye(ck.shape[0]),0.5*ck.T@np.conj(ck)))
        l1=[0 for x in range(5)]
        l2=[0 for x in range(5)]
        l1[1]=sqrt(gama*(1-fd(ek[1],UL,TL)))*ak[1]
        l1[2]=sqrt(gama*(1-fd(ek[2],UL,TL)))*ak[2]
        l1[3]=sqrt(gama*(1-fd(ek[3],UR,TR)))*ak[3]
        l1[4]=sqrt(gama*(1-fd(ek[4],UR,TR)))*ak[4]
        l2[1]=sqrt(gama*(fd(ek[1],UL,TL)))*ak[1].conj().T
        l2[2]=sqrt(gama*(fd(ek[2],UL,TL)))*ak[2].conj().T
        l2[3]=sqrt(gama*(fd(ek[3],UR,TR)))*ak[3].conj().T
        l2[4]=sqrt(gama*(fd(ek[4],UR,TR)))*ak[4].conj().T

        lind=lambda es,ek:-1.j*(kron((ham(es,ek)),eye(ham(es,ek).shape[0]))-kron(eye(ham(es,ek).shape[0]),ham(es,ek).T))\
            +2*(DLind(l1[1])+DLind(l1[2])+DLind(l1[3])+DLind(l1[4])+DLind(l2[1])+DLind(l2[2])+DLind(l2[3])+DLind(l2[4]))
        ll=lambda es,ek:lind(es,ek).conj().T@lind(es,ek)    
        return ll(es,ek)


    el0=np.arange(-5,5.1,de)
    NS=len(el0)
    el=np.append(el0,el0)
    ek=np.append(es,el)

    ham=singlelevel_ham_fermionop(ek,t_cp)
    liouvi=liouville_qubit_superop(ham,ek)
    liolio=hermitian_conjugated(liouvi)*liouvi
    # dll=qubit_operator_sparse(liolio)
    # dl= diag_lind(t_cp)
    # print((dll-dl).sum())
    qubit_total=2*len(ek)
    return qubit_total ,liolio,t_cp

#singlelevlindmaster()
    
class isingmd():
    def __init__(self,pram,sz) -> None:
        self.prameter=pram
        self.size=sz
        self.ising_ham=self.construct_dissising_ham(pram,sz)
        self.liouville=self.construct_ising_liouville_super_op(self.ising_ham,self.size)
        self.liolio=hermitian_conjugated(self.liouville)*self.liouville
        pass

    def construct_dissising_ham(self,pram,sz):
        ham=QubitOperator()
        for i in range(sz):
            if i+1<sz:
                ham+=QubitOperator(((i,'Z'),(i+1,'Z')),0.5)+QubitOperator((i,'X'),pram)
            else:
                ham+=QubitOperator((i,'X'),pram)
        return ham
    
    def construct_dissipator(self,sz):
        l1=[]
        l2=[]
        for i in range(sz):
            sigma_1=0.5*(QubitOperator(((i,'X')),1)+QubitOperator(((i,'Y')),-1j))
            sigma_2=QubitOperator(((i,'Z')),1)
            l1.append(sigma_1)
            l2.append(sigma_2)

        return l1,l2
    
    def construct_ising_liouville_super_op(self,ising_ham,sz):
        ising_ham_trans=trans_QubitOperator(ising_ham,sz)
        l1,l2=self.construct_dissipator(sz)
        jl1=construct_choi_qubit2qubit_dissipator(l1,sz)
        jl2=construct_choi_qubit2qubit_dissipator(l2,sz)
        return -1.j*(ising_ham-ising_ham_trans)+(jl1+jl2)


# qo=QubitOperator((((4, 'X'), (5, 'Y'), (6, 'X'), (7, 'Y'))))+QubitOperator((((1, 'X'), (2, 'Y'), (3, 'X'))))
# qoo=trans_QubitOperator(qo,10)
# print(qoo)


def openfermion2qiskit_qubitlist(qubit_op,size):
    '''
    将openfermion提供的哈密顿量信息转为支持的泡利字符串
    H = [
    ("II", -1.0537076071291125),
    ("IZ", 0.393983679438514),
    ("ZI", -0.39398367943851387),
    ("ZZ", -0.01123658523318205),
    ("XX", 0.1812888082114961),
    ]
    '''
    info_dic = qubit_op.terms

    
    def reverse_string(s):
        return ''.join(reversed(s))
    def process_tuple(tup):
        if len(tup) == 0:
            res=''
            for i in range(size):
                res+='I'
            return res
        else:
            idx=0
            iod=0
            res = ''
            for ele in tup:
                if iod==0 and ele[0]>0:
                    for i in range(ele[0]):
                        res+='I'
                else:
                    if ele[0]-idx>1:
                        for i in range(ele[0]-idx-1):
                            res+='I'
                idx=ele[0]
                res += ele[1]
                iod+=1
            if len(res)<size:
                for i in range(size - len(res)):
                    res+='I'
            if len(res)>size:
                raise('error ')
            # res=reverse_string(res)
            return res
    H_info = []

    for keys in qubit_op.terms.keys():
        if qubit_op.terms[keys]!=0:
            H_info.append((process_tuple(keys),qubit_op.terms[keys]))
    
    # print(len(H_info))

    return H_info


import matplotlib.pyplot as mpl
# from qiskit import *
# from qiskit.circuit.library import TwoLocal
# from qiskit.circuit import QuantumCircuit, Parameter, ParameterVector
# from qiskit.quantum_info.operators import Operator, Pauli
# from qiskit.quantum_info import process_fidelity
# from qiskit.circuit.library import TwoLocal
# from qiskit.opflow import PauliSumOp
# from qiskit.utils import QuantumInstance
# from qiskit_aer import AerSimulator
# from qiskit.quantum_info import process_fidelity
# from qiskit.algorithms import VQE as VQEOD
# from qiskit.algorithms.optimizers import SPSA ,SLSQP,BOBYQA,L_BFGS_B,CG,COBYLA
# from qiskit.quantum_info import *
# from qiskit_aer.primitives import Estimator as AerEstimator
# from qiskit.algorithms.minimum_eigensolvers import NumPyMinimumEigensolver
# import numpy
# from qiskit_algorithms.minimum_eigensolvers import VQE  # new import!!!
# from qiskit_algorithms.optimizers import SPSA,SLSQP,L_BFGS_B
# from qiskit.circuit.library import TwoLocal
# from qiskit.quantum_info import SparsePauliOp
# from qiskit.primitives import Estimator,Sampler
# from qiskit_aer.primitives import Estimator as AerEstimator

sigma_x=np.array([[0.,1],[1.,0]])
sigma_y=np.array([[0.,-1.j],[1.j,0]])
sigma_z=np.array([[1,0],[0,-1]])
x1=kron(np.eye(sigma_x.shape[0]),sigma_x,)
y1=kron(np.eye(sigma_y.shape[0]),sigma_y,)
z1=kron(np.eye(sigma_z.shape[0]),sigma_z,)

def hea_dvqe(qwork,reps):
    numb_operators0=999
    qnub=int(2*qwork)
    # print('tot_q:',qnub)
    thetas = ParameterVector('pn',numb_operators0)
    qc = QuantumCircuit(qnub)
    count_num=0

    for blocks in range(reps):
        for qn in range(qwork):
            qc.ry(thetas[count_num],qn)
            count_num +=1
        for qn in range(qwork-1):
            qc.cry(thetas[count_num],qn,qn+1)
            count_num +=1
    # qc.barrier()
    for qn in range(qwork):
        if qn+qwork <qnub:
            qc.cx(qn,qn+qwork)
    # qc.barrier()
    for blocks in range(reps):
        for qn in range(qwork):
            qc.ry(thetas[count_num],qn)
            qc.ry(thetas[count_num+1],qn+qwork)
            count_num+=2
        for qn in range(qwork):
            qc.rx(thetas[count_num],qn)
            qc.rx(thetas[count_num+1],qn+qwork)
            count_num+=2
        for qn in range(qwork):
            if qn+1<qwork:
                qc.cz(qn,qn+1)
                qc.cz(qn+qwork,qn+qwork+1)
        # qc.barrier()
    for qn in range(qwork):
        qc.ry(thetas[count_num],qn)
        qc.ry(thetas[count_num+1],qn+qwork)
        count_num+=2
    for qn in range(qwork):
        qc.rx(thetas[count_num],qn)
        qc.rx(thetas[count_num+1],qn+qwork)
        count_num+=2
    numb_operators=count_num
    thetas = ParameterVector('pn',numb_operators)
    return qc

def qiskit_qer(qiskit_quibit_list,qwork,qc,pram=None):


    # qc.decompose().draw('mpl')
    # mpl.show()
    hamiltonian = PauliSumOp.from_list(qiskit_quibit_list)
    opt = SLSQP(maxiter=5000)
    
    # backend = AerSimulator()
    # qi = QuantumInstance(backend=backend)
    # vqe = VQEOD(qc, optimizer=opt, quantum_instance=qi,initial_point=pram)

    estimator = Estimator()
    vqe = VQE(estimator, qc, opt,initial_point=pram)
    
    result = vqe.compute_minimum_eigenvalue(hamiltonian)
    fai=Statevector(qc.assign_parameters(result.optimal_parameters))
    pram=result.optimal_point
    print(result.eigenvalue)

    # solver = NumPyMinimumEigensolver()
    # result = solver.compute_minimum_eigenvalue(hamiltonian)
    # fai=result.eigenstate
    # print(result.eigenvalue)

    rou=numpy.array(fai).reshape(2**qwork,2**qwork)
    rou=rou/rou.trace()
    return rou,pram

import matplotlib.pyplot as mpl

def ising_NumPyMinimumEigensolver(size):    
    xba=[]
    yba=[]
    zba=[]
    idx=[]
    xb_s="X"
    yb_s="Y"
    zb_s="Z"
    for i in range(1,size):
        xb_s+='I'
        yb_s+='I'
        zb_s+='I'
    xb=SparsePauliOp(xb_s).to_matrix()
    yb=SparsePauliOp(yb_s).to_matrix()
    zb=SparsePauliOp(zb_s).to_matrix()
    # print(xb_s,yb_s,zb_s)
    pram=None
    qc=hea_dvqe(size,2)
    for i in range(30):
        print('ite:',i)
        g_pra=i*0.1
        ltlt=isingmd(g_pra,size).liolio
        ltlt=openfermion2qiskit_qubitlist(ltlt,size*2)
        rou,pram=qiskit_qer(ltlt,size,qc,pram)
        xba.append((rou@xb).trace())
        yba.append((rou@yb).trace())
        zba.append((rou@zb).trace())
        idx.append(g_pra)
    mpl.plot(idx,xba,'ro-')
    mpl.plot(idx,yba,'bo-')
    mpl.plot(idx,zba,'co-')
    mpl.show()

#ising_NumPyMinimumEigensolver(3)
# tq,ltlt=singlelevlindmaster(1,2)
# ltlt=openfermion2qiskit_qubitlist(ltlt,tq)
# qiskit_qer(ltlt)
def juction_NumPyMinimumEigensolver(n_leads_level):
    yita=(n_leads_level+1)/10
    t_cp=sqrt(1/(2*pi*yita))
    nwork=(n_leads_level+1)*2+1
    tot_qubit=nwork*2
    occ=[]
    idx=[]
    jc=[]
    n_s=jordan_wigner(FermionOperator("0^ 0"))
    n_1=jordan_wigner(FermionOperator("1^ 0",1j)-FermionOperator("0^ 1",1j))
    n_s=openfermion2qiskit_qubitlist(n_s,nwork)
    n_1=openfermion2qiskit_qubitlist(n_1,nwork)
    # print(n_1)
    n_s=PauliSumOp.from_list(n_s).to_matrix()
    n_1=PauliSumOp.from_list(n_1).to_matrix()
    qc=hea_dvqe(nwork,2)
    for i in range(15):
        g_pra=-3+i*0.5
        tq,ltlt=singlelevlindmaster(n_leads_level,g_pra)
        ltlt=openfermion2qiskit_qubitlist(ltlt,tq)
        rou,pram=qiskit_qer(ltlt,int(tq/2),qc)
        occ.append((rou@n_s).trace())
        j1=(rou@n_1).trace()
        jc.append(-t_cp*j1)
        idx.append(g_pra)
    # mpl.plot(idx,occ,'ro-')
    mpl.plot(idx,jc,'bo-')
    mpl.show()

#juction_NumPyMinimumEigensolver(1)
# ising_NumPyMinimumEigensolver(2)
