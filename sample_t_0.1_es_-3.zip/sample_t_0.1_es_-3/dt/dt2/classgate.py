'''
Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
Date: 2024-07-12 16:37:50
LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
LastEditTime: 2024-07-13 15:30:13
FilePath: /ly/classgate.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import numpy as np
from scipy.sparse import eye,kron
from scipy.sparse import csc_array as array
from numpy import zeros
import matplotlib.pyplot as mpl
from matplotlib.pyplot import MultipleLocator
import scipy
import scipy.optimize as optz
from scipy.sparse.linalg import expm
from scipy.linalg import sqrtm
import math
from cmath import exp, sqrt,pi,sin,cos
id2=eye(2)
s0=array([[1.],[0.]])
s1=array([[0.],[1.]])
k00=s0*s0.conj().T
k11=s1*s1.conj().T
sigma_x=array([[0.,1],[1.,0]])
sigma_y=array([[0.,-1.j],[1.j,0]])
sigma_z=array([[1,0],[0,-1]])

sigma_p=(sigma_x+1.j*sigma_y)/2
sigma_m=(sigma_x-1.j*sigma_y)/2

rx=lambda x: cos(x/2)*id2-1j*sin(x/2)*sigma_x
ry=lambda x: cos(x/2)*id2-1j*sin(x/2)*sigma_y
rz=lambda x: cos(x/2)*id2-1j*sin(x/2)*sigma_z

def to_bin(value, num):#十进制数据，二进制位宽
	bin_chars = ""
	temp = value
	for i in range(num):
		bin_char = bin(temp % 2)[-1]
		temp = temp // 2
		bin_chars = bin_char + bin_chars
	return bin_chars.upper()#输出指定位宽的二进制字符串

def pwkron(mat,n):
    if n==0:
        rs=array([[1]])
    elif n==1:
        rs=mat
    elif n>1:
        rs=kron(mat,pwkron(mat,n-1))
    return rs

def Circ_Singlegate(singlegate,targ,totq):
    targ=targ+1
    qcy=kron(kron(pwkron(id2,targ-1),singlegate),pwkron(id2,totq-targ))
    return qcy

def Circ_RXXgate(qgate,tq1,tq2,totq):
    tq1=tq1+1
    tq2=tq2+1
    tmp=kron(kron(pwkron(id2,tq1-1),qgate),kron(pwkron(id2,tq2-tq1-1),qgate))
    tmp=kron(tmp,pwkron(id2,totq-tq2))
    return tmp

    
def Circ_Controlgate(singlegate,controlq,targetq,totq):
    controlq=controlq+1
    targetq=targetq+1
    if controlq<targetq :
        i00=kron(kron(pwkron(id2,controlq-1),k00),pwkron(id2,totq-controlq))
        i111=kron(pwkron(id2,controlq-1),k11)
        i112=kron(i111,kron(pwkron(id2,targetq-controlq-1),singlegate))
        i113=kron(i112,pwkron(id2,totq-targetq))
        y=i00+i113
    elif controlq>targetq:
        i00=kron(kron(pwkron(id2,controlq-1),k00),pwkron(id2,totq-controlq))
        i111=kron(pwkron(id2,targetq-1),singlegate)
        i112=kron(i111,kron(pwkron(id2,controlq-targetq-1),k11))
        i113=kron(i112,pwkron(id2,totq-controlq))
        y=i00+i113
    return y

class RX():
    def __init__(self,pram,tq1,totq):
        generator=sigma_x
        self.x0=cos(pram/2)*id2-1j*sin(pram/2)*generator
        self.grad0=-1j/2*self.x0*generator
        self.x=Circ_Singlegate(self.x0,tq1,totq)
        self.grad=Circ_Singlegate(self.grad,tq1,totq)

class RY():
    def __init__(self,pram,tq1,totq):
        generator=sigma_y
        self.x0=cos(pram/2)*id2-1j*sin(pram/2)*generator
        self.grad0=-1j/2*self.x0*generator
        self.x=Circ_Singlegate(self.x0,tq1,totq)
        self.grad=Circ_Singlegate(self.grad,tq1,totq)

class RZ():
    def __init__(self,pram,tq1,totq):
        generator=sigma_z
        self.x0=cos(pram/2)*id2-1j*sin(pram/2)*generator
        self.grad0=-1j/2*self.x0*generator
        self.x=Circ_Singlegate(self.x0,tq1,totq)
        self.grad=Circ_Singlegate(self.grad,tq1,totq)

class RXX():
    def __init__(self,pram,tq1,tq2,totq):
        generator=Circ_RXXgate(sigma_x,tq1,tq2,totq)
        idt=eye((generator).shape[0])
        self.x=cos(pram/2)*idt-1j*sin(pram/2)*generator
        self.grad=-1j/2*(cos(pram/2)*generator-1j*sin(pram/2)*idt)

class RYY():
    def __init__(self,pram,tq1,tq2,totq):
        generator=Circ_RXXgate(sigma_y,tq1,tq2,totq)
        idt=eye((generator).shape[0])
        self.x=cos(pram/2)*idt-1j*sin(pram/2)*generator
        self.grad=-1j/2*(cos(pram/2)*generator-1j*sin(pram/2)*idt)

class RZZ():
    def __init__(self,pram,tq1,tq2,totq):
        generator=Circ_RXXgate(sigma_z,tq1,tq2,totq)
        idt=eye((generator).shape[0])
        self.x=cos(pram/2)*idt-1j*sin(pram/2)*generator
        self.grad=-1j/2*(cos(pram/2)*generator-1j*sin(pram/2)*idt)

class U3():
    def __init__(self,lambd,sita,fai,tq1,totq):
        # u3x=exp(1j*(lambd)/2)*rx(pi/2)@rz(lambd)
        # u3y=rx(pi/2)@rz(sita+pi)
        # u3z=exp(1j*(fai)/2)*rz(fai+3*pi)
        u3x=sin(pi/4)*np.array([[1,-1.j*exp(1j*lambd)],[-1.j,exp(1j*lambd)]])
        u3y=sin(pi/4)*np.array([[-exp(-1j/2*sita)*1.j,exp(1j/2*sita)],[-exp(-1j/2*sita),1j*exp(1j/2*sita)]])
        u3z=np.array([[1j,0],[0,-1j*exp(1j*fai)]])
        u3=np.array([[cos(sita/2),-exp(1j*lambd)*sin(sita/2)],[exp(1j*fai)*sin(sita/2),exp(1j*lambd+1j*fai)*cos(sita/2)]])
        self.x=Circ_Singlegate(u3,tq1,totq)
        u31=(1j/2)*u3x@(eye(2)-sigma_z)
        u32=(1j/2)*u3y@(-sigma_z)
        u33=(1j/2)*u3z@(eye(2)-sigma_z)
        self.x1=Circ_Singlegate(u3x,tq1,totq)
        self.x2=Circ_Singlegate(u3y,tq1,totq)
        self.x3=Circ_Singlegate(u3z,tq1,totq)
        self.grad1=Circ_Singlegate(u31,tq1,totq)
        self.grad2=Circ_Singlegate(u32,tq1,totq)
        self.grad3=Circ_Singlegate(u33,tq1,totq)

class CX():
    def __init__(self,ctrlq,targq,totq):
        self.x=Circ_Controlgate(sigma_x,ctrlq,targq,totq)
        self.grad=0

class UX():
    def __init__(self,tarq,totq):
        self.x=Circ_Singlegate(sigma_x,tarq,totq)
        self.grad=0

class UY():
    def __init__(self,tarq,totq):
        self.x=Circ_Singlegate(sigma_y,tarq,totq)
        self.grad=0

class UZ():
    def __init__(self,tarq,totq):
        self.x=Circ_Singlegate(sigma_z,tarq,totq)
        self.grad=0