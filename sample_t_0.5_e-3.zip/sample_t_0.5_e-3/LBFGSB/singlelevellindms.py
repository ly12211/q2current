'''
Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
Date: 2024-03-19 14:20:50
LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
LastEditTime: 2024-03-21 16:39:32
FilePath: /ly/singlelevellindms.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
from openlind import *
from classgate import *
from numpy import trace,sum
# totq,ltlt=singlelevlindmaster(1,0)
# ltlt=isingmd(0,2).liolio
# ltlt=qubit_operator_sparse(ltlt)
# print (ltlt.todense())

def dhea(x,d1,d2,totq):
    workq=int(totq/2)
    k=0
    fa0=1j*zeros((2**workq,1))
    fa0[0]=1.0+0j
    circ=fa0
    qgt=[]
    dqgt=[]
    uwork=eye(2**workq)
    for i in range(d1):
        for nq in range(workq):
            qc=U3(x[k],x[k+1],x[k+2],nq,workq)
            qgt.append(qc.x1)
            qgt.append(qc.x2)
            qgt.append(qc.x3)
            dqgt.append(qc.grad1)
            dqgt.append(qc.grad2)
            dqgt.append(qc.grad3)
            circ=qc.x@circ
            k=k+3
            del qc
        for nq in range(workq-1):
            qc=RXX(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RYY(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RZZ(x[k],nq,nq+1,workq)
            circ=qc.x@circ
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            k=k+1
            del qc
    circa=circ
    circb=fa0
    cica=[circ for x in range(2**workq)]
    cicb=[fa0 for x in range(2**workq)]
    tp_left=[k00,k11]
    tp_right=[eye(2),sigma_x]
    for i in range(2**workq):
        bin2=to_bin(i,workq)
        for j in range(workq):
            singlegatel=tp_left[int(bin2[j])]
            singlegater=tp_right[int(bin2[j])]
            cica[i]=Circ_Singlegate(singlegatel,j,workq)@cica[i]
            cicb[i]=Circ_Singlegate(singlegater,j,workq)@cicb[i]

    for nq in range(workq):
        qc=CX(nq,nq+workq,totq)
        qgt.append(qc.x)
        dqgt.append(qc.grad)
        k=k+1
        del qc
    for i in range(d2):
        for nq in range(workq):
            qc=U3(x[k],x[k+1],x[k+2],nq,workq)
            qgt.append(qc.x1)
            qgt.append(qc.x2)
            qgt.append(qc.x3)
            dqgt.append(qc.grad1)
            dqgt.append(qc.grad2)
            dqgt.append(qc.grad3)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+3
            del qc
        for nq in range(workq-1):
            qc=RXX(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RYY(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
        for nq in range(workq-1):
            qc=RZZ(x[k],nq,nq+1,workq)
            qgt.append(qc.x)
            dqgt.append(qc.grad)
            for j in range(2**workq):
                cica[j]=qc.x@cica[j]
                cicb[j]=qc.x.conj()@cicb[j]
            k=k+1
            del qc
    circ=0
    for i in range(2**workq):
        circ+=kron(cica[i],cicb[i])

    return circ,qgt,dqgt

def np_dhea(d1,d2,totq):
    workq=int(totq/2)
    k=0
    for i in range(d1):
        for nq in range(workq):
            k=k+3
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
    for nq in range(workq):
            k=k+1
    n2=k
    for i in range(d2):
        for nq in range(workq):
            k=k+3
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
        for nq in range(workq-1):
            k=k+1
    return k,n2


Nfeval = 1


def ising_solver(size,d1,d2):
    xba=[]
    yba=[]
    zba=[]
    Xba=[]
    Yba=[]
    Zba=[]
    idx=[]
    method='BFGS'
    nprm,n2=np_dhea(d1,d2,size*2)
    pram=zeros(nprm)
    
    xb=UX(0,size).x
    yb=UY(0,size).x
    zb=UZ(0,size).x
    sz=2**size
    iwork=eye(2**size)
    for i in range(15):
        print('ite:',i)
        g_pra=i*0.2
        ltlt=isingmd(g_pra,size).liolio
        ltlt=qubit_operator_sparse(ltlt)
        
        def ell(x):
            fx,qg,dqg=dhea(x,d1,d2,size*2)
            fai=fx
            fx=ltlt@fx
            inner=trace(fai.conj().T@fx)
            lamb=fx
            jac=zeros(nprm)
            for i in range(nprm-1,-1,-1):
                if i>=n2:
                    qg0=kron(qg[i].conj().T,qg[i].transpose())
                    fai=qg0@fai
                    uv=fai
                    uv=(kron(dqg[i],(qg[i]).conj())+kron(qg[i],(dqg[i]).conj()))@uv
                    jac[i]=2*(trace(lamb.conj().T@uv)).real
                else:
                    if i>=n2-size:
                        fai=qg[i].conj().T@fai
                        jac[i]=0
                    else:
                        qg0=kron(qg[i].conj().T,iwork)
                        fai=qg0@fai
                        uv=fai
                        uv=kron(dqg[i],iwork)@uv
                        jac[i]=2*(trace(lamb.conj().T@uv)).real

                if i>=n2 or i<n2-size:
                    lamb=qg0@lamb
                else:
                    lamb=qg[i].conj().T@lamb
            return inner ,jac
        def callbackF(Xi):
            global Nfeval
            rs,rg=ell(Xi)
            print (Nfeval, rs)
            with open("optdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(Xi))
                f.close()
            with open("gradparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(rg))
                f.close()
            with open("opt%s%s.txt"%(d1,d2),"a") as f2:
                f2.write(str(rs))
                f2.write("\n")
                f2.close()
            Nfeval += 1
        opt=optz.minimize(ell, x0=pram,method=method,jac=True,callback=callbackF)
        with open("dvqeparameters%s%s.txt"%(d1,d2),"a") as fp:
            fp.write(str(opt.x))
            fp.write("\n")
            fp.close()
        ev,qg,dqg=dhea(opt.x,d1,d2,size*2)
        # ev=ev.reshape(size(ev))
        rou=ev.reshape(sz,sz)
        rou=rou/trace(rou)
        ed,vd=scipy.sparse.linalg.eigsh(ltlt,k=1,which='SA')
        roud=vd.reshape(sz,sz)
        roud=roud/trace(roud)
        xba.append((rou@xb).trace())
        yba.append((rou@yb).trace())
        zba.append((rou@zb).trace())
        Xba.append((roud@xb).trace())
        Yba.append((roud@yb).trace())
        Zba.append((roud@zb).trace())
        idx.append(g_pra)
        pram=opt.x
    mpl.plot(idx,xba,'ro')
    mpl.plot(idx,yba,'bo')
    mpl.plot(idx,zba,'co')
    mpl.plot(idx,Xba,'r-')
    mpl.plot(idx,Yba,'b-')
    mpl.plot(idx,Zba,'c-')
    mpl.savefig("ising%s%s.png"%(d1,d2))


def singlelevelmod_solver(nleadlvs,d1,d2):
    occ=[]
    occ_d=[]
    idx=[]
    jc=[]
    jc_d=[]
    method='L-BFGS-B'
    size=(nleadlvs+1)*2+1
    sz=2**size
    nprm,n2=np_dhea(d1,d2,size*2)
    pram=zeros(nprm)
    pram=[
  1.81214873e-09, -3.30581191e+00,  3.14160074e+00,  1.84785316e-09,
  2.92751646e+00,  1.57078655e+00,  1.88761884e-09,  1.41164898e+00,
 -1.60549080e+00,  1.85865326e-09,  3.88436271e+00,  3.50867984e-01,
  1.85506669e-09, -6.13711904e-07, -8.40854920e-01, -2.21554961e+00,
 -8.50511963e-08, -2.46170316e-01,  4.78486835e-06, -2.23323428e+00,
  4.58321819e-06,  7.76615516e-01, -3.66225596e-06, -2.88508075e-06,
  5.20094839e+00, -6.83890639e+00,  1.39413470e+00,  0.00000000e+00,
  0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
  3.33401880e-04,  2.15935075e-10, -1.44837729e+01,  8.23896267e-04,
 -1.36147494e-10,  4.03208154e+00,  3.63184288e-04, -1.39558857e-08,
 -6.50673157e+00,  9.72634559e-04, -2.76814310e-10, -1.39285831e+00,
  3.28497941e-04, -4.20525727e-11,  4.88605956e-01,  1.56989245e+00,
 -1.79920761e-04, -4.39821610e-02, -7.88782292e-01, -8.92534886e-01,
  1.56424386e+00,  6.29343489e-02,  2.91437438e-01, -4.94989931e-02,
 -6.28318247e+00,  1.36933446e-08,  2.89462001e-06, -4.93162248e+00,
 -2.62223438e-10,  5.56921378e+00, -2.82943445e+00, -5.83667168e-11,
  1.35832539e+00,  7.74310298e-01,  1.01231925e-10, -8.07066558e-01,
 -3.00474392e+00, -3.12922179e-10,  2.24011337e+00,  2.92695890e+00,
 -4.63673578e-11, -4.78759850e+00,  4.46700670e-01, -1.95901361e+00,
 -1.72660084e-03,  1.18720804e+00, -1.52533955e+00,  1.91176629e+00,
  4.47914423e-02, -8.68029469e-01, -1.48737926e-04, -1.14584581e-04,
  9.83786838e-08,  7.30859575e-05, -3.64218498e+00, -2.53640819e-10,
  2.05053147e+00, -8.29095349e-01,  2.55863515e-11,  5.73395082e+00,
 -5.68065880e+00, -2.42314139e-11,  5.75963829e+00,  4.87340178e+00,
  2.63422435e-10, -3.31268584e+00,  1.36787673e+00,  1.89489772e-10,
 -1.21935748e+00, -7.51227207e-02,  1.57883564e+00, -2.55803777e-03,
 -2.02058349e+00, -1.56653207e+00, -2.64612631e+00, -1.15293753e-03,
  1.57597921e+00, -3.14282064e+00, -3.13965968e+00,  3.14159288e+00,
 -7.66215942e-05]
    iwork=eye(2**size)
    n_s=jordan_wigner(FermionOperator("0^ 0"))
    n_s=qubit_operator_sparse(n_s)
    uw=eye(2**(size-1))
    n_s=kron(n_s.todense(),uw)
    n_l1=-jordan_wigner(FermionOperator("1^ 0",1j)-FermionOperator("0^ 1",1j))
    n_l2=-jordan_wigner(FermionOperator("2^ 0",1j)-FermionOperator("0^ 2",1j))
    n_l1=qubit_operator_sparse(n_l1)
    n_l2=qubit_operator_sparse(n_l2)
    n_l1=kron(n_l1.todense(),eye(2**(size-2)))
    n_l2=kron(n_l2.todense(),eye(2**(size-3)))
    n_r1=-jordan_wigner(FermionOperator("3^ 0",1j)-FermionOperator("0^ 3",1j))
    n_r2=-jordan_wigner(FermionOperator("4^ 0",1j)-FermionOperator("0^ 4",1j))
    n_r1=qubit_operator_sparse(n_r1)
    n_r2=qubit_operator_sparse(n_r2)
    n_r1=kron(n_r1.todense(),eye(2**(size-4)))
    n_r2=n_r2.todense() 
    # n_s=kron(n_s,pwkron(id2,size-1))
    # n_1=jordan_wigner(FermionOperator("1^ 0",1j)-FermionOperator("0^ 1",1j))
    # n_s=openfermion2qiskit_qubitlist(n_s,size)
    # n_1=openfermion2qiskit_qubitlist(n_1,size)
    # n_s=PauliSumOp.from_list(n_s).to_matrix()
    # n_1=PauliSumOp.from_list(n_1).to_matrix()
    with open("data%s%s.txt"%(d1,d2),"a") as f2:
        f2.write('idx      occ     occ_d      jc      jc_d')
        f2.write("\n")
        f2.close()
    for i in range(60):
        print('ite:',i)
        # g_pra=-3+i*0.5
        g_pra=8+i*0.5
        tq,ltlt,t_cp=singlelevlindmaster(nleadlvs,-3,g_pra,0.5)
        ltlt=qubit_operator_sparse(ltlt)
        ed,vd=scipy.sparse.linalg.eigsh(ltlt,k=1,which='SA')
        roud=vd.reshape(sz,sz)
        roud=roud/trace(roud)
        def ell(x):
            fx,qg,dqg=dhea(x,d1,d2,size*2)
            fai=fx
            fx=ltlt@fx
            inner=(fai.conj().T@fx).sum()
            lamb=fx
            jac=zeros(nprm)
            for i in range(nprm-1,-1,-1):
                if i>=n2:
                    qg0=kron(qg[i].conj().T,qg[i].transpose())
                    fai=qg0@fai
                    uv=fai
                    uv=(kron(dqg[i],(qg[i]).conj())+kron(qg[i],(dqg[i]).conj()))@uv
                    jac[i]=2*((lamb.conj().T@uv).trace()).real
                else:
                    if i>=n2-size:
                        fai=qg[i].conj().T@fai
                        jac[i]=0
                    else:
                        qg0=kron(qg[i].conj().T,iwork)
                        fai=qg0@fai
                        uv=fai
                        uv=kron(dqg[i],iwork)@uv
                        jac[i]=2*((lamb.conj().T@uv).trace()).real
                if i>=n2 or i<n2-size:
                    lamb=qg0@lamb
                else:
                    lamb=qg[i].conj().T@lamb
            return inner ,jac
        def callbackF(Xi):
            global Nfeval
            rs,rg=ell(Xi)
            print (Nfeval, rs)
            with open("optdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(Xi))
                f.close()
            with open("gradparameters%s%s.txt"%(d1,d2),"w") as f:
                f.write(str(rg))
                f.close()
            def print_gate_np_dhea(totq,x):
                with open("gateoptdvqeparameters%s%s.txt"%(d1,d2),"w") as f:
                    workq=int(totq/2)
                    k=0
                    f.write('Parameters in D\n')
                    for i in range(d1):
                        for nq in range(workq):
                            f.write(('qubit:%s  Gate:U3 Pm%s %s %s\n'%(nq,x[k],x[k+1],x[k+2])))
                            k=k+3
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RXX Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RYY Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RZZ Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                    for nq in range(workq):
                            f.write('qubit:%s qubit:%s  Gate:CX Pm%s\n'%(nq,nq+workq,x[k]))
                            k=k+1
                    f.write('Parameters in V\n')
                    for i in range(d2):
                        for nq in range(workq):
                            f.write('qubit:%s  Gate:U3 Pm%s %s %s\n'%(nq,x[k],x[k+1],x[k+2]))
                            k=k+3
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RXX Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RYY Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1
                        for nq in range(workq-1):
                            f.write('qubit:%s qubit:%s  Gate:RZZ Pm%s\n'%(nq,nq+1,x[k]))
                            k=k+1 
                    f.close()
            print_gate_np_dhea(size*2,Xi)
            with open("opt%s%s.txt"%(d1,d2),"a") as f2:
                f2.write(str(rs))
                f2.write("\n")
                f2.close()
            Nfeval += 1
        opt=optz.minimize(ell, x0=pram,method=method,jac=True,callback=callbackF)
        with open("dvqeparameters%s%s.txt"%(d1,d2),"a") as fp:
            fp.write(str(opt.x))
            fp.write("\n")
            fp.close()
        ev,qg,dqg=dhea(opt.x,d1,d2,size*2)
        # ev=ev.reshape(size(ev))
        rou=ev.reshape(sz,sz)
        rou=rou/rou.trace()
        idx.append(g_pra)
        tocc=np.sum((rou@n_s).trace())
        tocc_d=np.sum((roud@n_s).trace())
        occ.append(tocc)
        occ_d.append(tocc_d)
        sja=(rou@n_l1).trace()+(rou@n_l2).trace()
        sjb=(rou@n_r1).trace()+(rou@n_r2).trace()
        tjc=t_cp*(np.sum(sja-sjb))/2
        jc.append(tjc)
        sjad=(roud@n_l1).trace()+(roud@n_l2).trace()
        sjbd=(roud@n_r1).trace()+(roud@n_r2).trace()
        tjc_d=t_cp*(np.sum(sjad-sjbd))/2
        jc_d.append(tjc_d)
        with open("data%s%s.txt"%(d1,d2),"a") as f2:
            f2.write(str(g_pra))
            f2.write("   ")
            f2.write(str(tocc))
            f2.write("   ")
            f2.write(str(tocc_d))
            f2.write("   ")
            f2.write(str(tjc))
            f2.write("   ")
            f2.write(str(tjc_d))
            f2.write("\n")
            f2.close()
        pram=opt.x

    fig1=mpl.figure(num=1)
    mpl.plot(idx,occ,'ro')
    mpl.plot(idx,occ_d,'r-')
    mpl.xlabel('V')
    mpl.ylabel('Occ Num',rotation=0)
    mpl.legend(['vqe','direct_diagnoalization'])
    mpl.savefig("occdg%s%s.png"%(d1,d2))

    fig1=mpl.figure(num=2)
    mpl.plot(idx,jc,'ro')
    mpl.plot(idx,jc_d,'r-')
    mpl.xlabel('V')
    mpl.ylabel('I',rotation=0)
    mpl.legend(['vqe','direct_diagnoalization'])
    mpl.savefig("jcdg%s%s.png"%(d1,d2))


# ising_solver(3,1,2)
singlelevelmod_solver(1,1,3)

